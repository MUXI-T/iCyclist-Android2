package com.example.icyclist;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import com.google.android.material.bottomnavigation.BottomNavigationView;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private BottomNavigationView bottomNavigationView;
    private FrameLayout fragmentContainer;
    private List<String> communityList;
    private CommunityAdapter communityAdapter;
    private User currentUser;
    private SharedPreferences sharedPreferences;

    private List<Post> postList;
    private PostAdapter postAdapter;

    private boolean isPublishing = false;
    private Handler mainHandler;

    // 用于保存当前显示的RecyclerView引用
    private RecyclerView currentPostsRecyclerView;
    private PostAdapter currentPostAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // 首先初始化 Handler
        mainHandler = new Handler(Looper.getMainLooper());

        try {
            // 获取当前用户
            currentUser = (User) getIntent().getSerializableExtra("currentUser");
            android.util.Log.d("iCyclist", "用户信息: " + (currentUser != null ? currentUser.getUsername() : "null"));

            if (currentUser == null) {
                android.util.Log.e("iCyclist", "用户信息为空，跳转到登录界面");
                startActivity(new Intent(this, LoginActivity.class));
                finish();
                return;
            }

            initViews();
            initData();
            setupBottomNavigation();
            showFeedFragment();

            sharedPreferences = getSharedPreferences("user_prefs", MODE_PRIVATE);
            android.util.Log.d("iCyclist", "应用初始化完成");

        } catch (Exception e) {
            android.util.Log.e("iCyclist", "应用初始化失败: " + e.getMessage(), e);
            showSafeToast("应用初始化失败");
        }
    }

    private void initViews() {
        bottomNavigationView = findViewById(R.id.bottom_navigation);
        fragmentContainer = findViewById(R.id.fragment_container);
    }

    private void initData() {
        try {
            communityList = new ArrayList<>();
            postList = new ArrayList<>();

            // 初始化社区列表
            communityList.add("公路车天地");
            communityList.add("山地车越野");
            communityList.add("城市通勤");
            communityList.add("长途骑行");
            communityList.add("装备讨论");

            // 初始化适配器
            communityAdapter = new CommunityAdapter(this, communityList);

            android.util.Log.d("iCyclist", "数据初始化成功，社区数量: " + communityList.size());
        } catch (Exception e) {
            android.util.Log.e("iCyclist", "数据初始化失败: " + e.getMessage());
        }
    }

    private void setupBottomNavigation() {
        bottomNavigationView.setOnItemSelectedListener(item -> {
            int itemId = item.getItemId();
            if (itemId == R.id.navigation_feed) {
                showFeedFragment();
                return true;
            } else if (itemId == R.id.navigation_community) {
                showCommunityFragment();
                return true;
            } else if (itemId == R.id.navigation_publish) {
                showPublishFragment();
                return true;
            } else if (itemId == R.id.navigation_profile) {
                showProfileFragment();
                return true;
            }
            return false;
        });
    }

    private void showFeedFragment() {
        try {
            clearFragmentContainer();
            View feedView = getLayoutInflater().inflate(R.layout.fragment_feed, fragmentContainer, false);
            fragmentContainer.addView(feedView);
            setupFeedRecyclerView(feedView);
        } catch (Exception e) {
            android.util.Log.e("iCyclist", "显示骑友圈失败: " + e.getMessage());
            showSafeToast("加载骑友圈失败");
        }
    }

    private void setupFeedRecyclerView(View feedView) {
        try {
            RecyclerView postsRecyclerView = feedView.findViewById(R.id.posts_recycler_view);
            SwipeRefreshLayout swipeRefreshLayout = feedView.findViewById(R.id.swipe_refresh_layout);

            if (postsRecyclerView != null) {
                // 确保数据已加载
                if (postList.isEmpty()) {
                    loadMockData();
                }

                postAdapter = new PostAdapter(this, postList);
                postsRecyclerView.setLayoutManager(new LinearLayoutManager(this));
                postsRecyclerView.setAdapter(postAdapter);

                // 保存当前RecyclerView和Adapter的引用
                currentPostsRecyclerView = postsRecyclerView;
                currentPostAdapter = postAdapter;
            }

            if (swipeRefreshLayout != null) {
                swipeRefreshLayout.setOnRefreshListener(() -> {
                    mainHandler.postDelayed(() -> {
                        loadMockData();
                        if (postAdapter != null) {
                            postAdapter.notifyDataSetChanged();
                        }
                        swipeRefreshLayout.setRefreshing(false);
                    }, 1000);
                });
            }
        } catch (Exception e) {
            android.util.Log.e("iCyclist", "初始化Feed列表失败: " + e.getMessage());
        }
    }

    private void showCommunityFragment() {
        try {
            clearFragmentContainer();
            View communityView = getLayoutInflater().inflate(R.layout.fragment_community, fragmentContainer, false);
            fragmentContainer.addView(communityView);

            RecyclerView communityRecyclerView = communityView.findViewById(R.id.community_recycler_view);
            if (communityRecyclerView != null && communityAdapter != null) {
                communityRecyclerView.setLayoutManager(new LinearLayoutManager(this));
                communityRecyclerView.setAdapter(communityAdapter);
            }
        } catch (Exception e) {
            android.util.Log.e("iCyclist", "显示兴趣社区失败: " + e.getMessage());
            showSafeToast("加载兴趣社区失败");
        }
    }

    private void showPublishFragment() {
        try {
            clearFragmentContainer();
            View publishView = getLayoutInflater().inflate(R.layout.fragment_publish, fragmentContainer, false);
            fragmentContainer.addView(publishView);
            setupPublishListener(publishView);
        } catch (Exception e) {
            android.util.Log.e("iCyclist", "显示发布界面失败: " + e.getMessage());
            showSafeToast("加载发布界面失败");
        }
    }

    private void setupPublishListener(View publishView) {
        android.widget.Button btnPublish = publishView.findViewById(R.id.btn_publish);
        android.widget.EditText etNewPost = publishView.findViewById(R.id.et_new_post);

        btnPublish.setOnClickListener(v -> {
            if (isPublishing) {
                return; // 防止重复点击
            }

            String content = etNewPost.getText().toString().trim();
            if (content.isEmpty()) {
                etNewPost.setError("请输入帖子内容");
                return;
            }

            isPublishing = true;
            btnPublish.setEnabled(false);

            try {
                // 创建新帖子
                Post newPost = new Post(
                        "post_" + System.currentTimeMillis(),
                        currentUser.getUserId(),
                        currentUser.getUsername(),
                        content
                );
                newPost.setLikeCount(0);
                newPost.setCommentCount(0);
                newPost.setTimestamp(System.currentTimeMillis());

                // 确保 postList 不为空
                if (postList == null) {
                    postList = new ArrayList<>();
                }

                // 添加到帖子列表顶部
                postList.add(0, newPost);

                // 更新用户发帖数
                if (currentUser != null) {
                    currentUser.setPostCount(currentUser.getPostCount() + 1);
                }

                // 显示成功消息
                showSafeToast("发布成功！");

                // 清空输入框
                etNewPost.setText("");

                // 立即更新骑友圈的显示
                updateFeedAfterPublish();

                // 延迟切换回骑友圈，确保数据已更新
                mainHandler.postDelayed(() -> {
                    showFeedFragment();
                    bottomNavigationView.setSelectedItemId(R.id.navigation_feed);
                    isPublishing = false;
                    btnPublish.setEnabled(true);
                }, 500);

            } catch (Exception e) {
                android.util.Log.e("iCyclist", "发布失败: " + e.getMessage());
                showSafeToast("发布失败");
                isPublishing = false;
                btnPublish.setEnabled(true);
            }
        });
    }

    // 新增方法：发布后立即更新骑友圈显示
    private void updateFeedAfterPublish() {
        try {
            // 如果当前有显示的RecyclerView，直接更新它
            if (currentPostsRecyclerView != null && currentPostAdapter != null) {
                // 通知适配器数据已更新
                currentPostAdapter.notifyItemInserted(0);
                // 滚动到顶部显示新发布的帖子
                currentPostsRecyclerView.scrollToPosition(0);
            }

            // 同时更新全局的postAdapter
            if (postAdapter != null) {
                postAdapter.notifyItemInserted(0);
            }

            android.util.Log.d("iCyclist", "骑友圈已更新，显示新发布的帖子");
        } catch (Exception e) {
            android.util.Log.e("iCyclist", "更新骑友圈显示失败: " + e.getMessage());
        }
    }

    private void showProfileFragment() {
        try {
            clearFragmentContainer();
            View profileView = getLayoutInflater().inflate(R.layout.fragment_profile, fragmentContainer, false);
            fragmentContainer.addView(profileView);
            setupProfileData(profileView);
            setupLogoutListener(profileView);
        } catch (Exception e) {
            android.util.Log.e("iCyclist", "显示个人中心失败: " + e.getMessage());
            showSafeToast("加载个人中心失败");
        }
    }

    private void setupProfileData(View profileView) {
        if (currentUser != null) {
            android.widget.TextView tvProfileUsername = profileView.findViewById(R.id.tv_profile_username);
            android.widget.TextView tvProfileUserId = profileView.findViewById(R.id.tv_profile_user_id);
            android.widget.TextView tvProfileBio = profileView.findViewById(R.id.tv_profile_bio);
            android.widget.TextView tvPostCount = profileView.findViewById(R.id.tv_post_count);
            android.widget.TextView tvFollowers = profileView.findViewById(R.id.tv_followers);
            android.widget.TextView tvFollowing = profileView.findViewById(R.id.tv_following);

            if (tvProfileUsername != null) tvProfileUsername.setText(currentUser.getUsername());
            if (tvProfileUserId != null) tvProfileUserId.setText("ID: " + currentUser.getUserId());
            if (tvProfileBio != null) tvProfileBio.setText(currentUser.getBio());
            if (tvPostCount != null) tvPostCount.setText(String.valueOf(currentUser.getPostCount()));
            if (tvFollowers != null) tvFollowers.setText(String.valueOf(currentUser.getFollowers()));
            if (tvFollowing != null) tvFollowing.setText(String.valueOf(currentUser.getFollowing()));
        }
    }

    private void setupLogoutListener(View profileView) {
        android.widget.Button btnLogout = profileView.findViewById(R.id.btn_logout);

        if (btnLogout != null) {
            btnLogout.setOnClickListener(v -> {
                // 清除所有登录状态，包括自动登录
                clearAllLoginStatus();

                // 跳转到登录界面
                Intent intent = new Intent(MainActivity.this, LoginActivity.class);
                startActivity(intent);
                finish();
            });
        }
    }

    private void clearAllLoginStatus() {
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.clear(); // 清除所有保存的数据
        editor.apply();
    }

    private void loadMockData() {
        try {
            if (postList == null) {
                postList = new ArrayList<>();
            }

            // 只在首次加载时添加模拟数据
            if (postList.isEmpty()) {
                Post post1 = new Post("1", "user001", "骑行爱好者小明", "今天完成了50公里骑行，沿途风景太美了！🚴‍♂️ #骑行日记");
                post1.setLikeCount(15);
                post1.setCommentCount(3);
                post1.setTimestamp(System.currentTimeMillis() - 3600000);

                Post post2 = new Post("2", "user002", "山地车手小李", "新买的Trek山地车，性能超赞！爬坡毫无压力！推荐给大家！");
                post2.setLikeCount(8);
                post2.setCommentCount(2);
                post2.setTimestamp(System.currentTimeMillis() - 7200000);

                Post post3 = new Post("3", "user003", "公路车爱好者小王", "周末有骑行活动吗？想找骑友一起骑行！有一起的吗？");
                post3.setLikeCount(12);
                post3.setCommentCount(5);
                post3.setTimestamp(System.currentTimeMillis() - 10800000);

                postList.add(post1);
                postList.add(post2);
                postList.add(post3);
            }
        } catch (Exception e) {
            android.util.Log.e("iCyclist", "加载模拟数据失败: " + e.getMessage());
        }
    }

    private void clearFragmentContainer() {
        if (fragmentContainer != null) {
            fragmentContainer.removeAllViews();
        }
    }

    // 安全的Toast显示方法，避免Toast队列溢出
    private void showSafeToast(String message) {
        if (mainHandler != null) {
            mainHandler.post(() -> {
                try {
                    Toast.makeText(MainActivity.this, message, Toast.LENGTH_SHORT).show();
                } catch (Exception e) {
                    android.util.Log.e("iCyclist", "显示Toast失败: " + e.getMessage());
                }
            });
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        // 清理Handler，防止内存泄漏
        if (mainHandler != null) {
            mainHandler.removeCallbacksAndMessages(null);
        }
    }
}