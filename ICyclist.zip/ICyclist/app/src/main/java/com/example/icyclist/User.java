package com.example.icyclist;

import java.io.Serializable;

public class User implements Serializable {
    private static final long serialVersionUID = 1L; // 添加序列化版本UID

    private String userId;
    private String username;
    private String password;
    private String avatar;
    private String bio;
    private int followers;
    private int following;
    private int postCount;

    public User() {}

    public User(String userId, String username, String password) {
        this.userId = userId;
        this.username = username;
        this.password = password;
        this.avatar = "";
        this.bio = "这个人很懒，什么都没有写～";
        this.followers = 0;
        this.following = 0;
        this.postCount = 0;
    }

    // Getters and Setters
    public String getUserId() { return userId; }
    public void setUserId(String userId) { this.userId = userId; }

    public String getUsername() { return username; }
    public void setUsername(String username) { this.username = username; }

    public String getPassword() { return password; }
    public void setPassword(String password) { this.password = password; }

    public String getAvatar() { return avatar; }
    public void setAvatar(String avatar) { this.avatar = avatar; }

    public String getBio() { return bio; }
    public void setBio(String bio) { this.bio = bio; }

    public int getFollowers() { return followers; }
    public void setFollowers(int followers) { this.followers = followers; }

    public int getFollowing() { return following; }
    public void setFollowing(int following) { this.following = following; }

    public int getPostCount() { return postCount; }
    public void setPostCount(int postCount) { this.postCount = postCount; }
}