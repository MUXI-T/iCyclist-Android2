package com.example.icyclist;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;
import android.widget.Toast;

import java.util.List;

public class PostAdapter extends RecyclerView.Adapter<PostAdapter.PostViewHolder> {

    private Context context;
    private List<Post> postList;

    public PostAdapter(Context context, List<Post> postList) {
        this.context = context;
        this.postList = postList;
    }

    @NonNull
    @Override
    public PostViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_post, parent, false);
        return new PostViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull PostViewHolder holder, int position) {
        Post post = postList.get(position);
        holder.bind(post);
    }

    @Override
    public int getItemCount() {
        return postList.size();
    }

    class PostViewHolder extends RecyclerView.ViewHolder {
        private ImageView userAvatar;
        private TextView username, timestamp, content, likeCount, commentCount, community;
        private ImageButton likeButton, commentButton;

        public PostViewHolder(@NonNull View itemView) {
            super(itemView);

            userAvatar = itemView.findViewById(R.id.user_avatar);
            username = itemView.findViewById(R.id.username);
            timestamp = itemView.findViewById(R.id.timestamp);
            content = itemView.findViewById(R.id.content);
            likeCount = itemView.findViewById(R.id.like_count);
            commentCount = itemView.findViewById(R.id.comment_count);
            likeButton = itemView.findViewById(R.id.like_button);
            commentButton = itemView.findViewById(R.id.comment_button);
            community = itemView.findViewById(R.id.community);
        }

        public void bind(Post post) {
            username.setText(post.getUsername());
            content.setText(post.getContent());
            likeCount.setText(String.valueOf(post.getLikeCount()));
            commentCount.setText(String.valueOf(post.getCommentCount()));
            community.setText(post.getCommunity());

            // 设置时间戳
            timestamp.setText(getTimeAgo(post.getTimestamp()));

            // 设置默认头像
            userAvatar.setImageResource(android.R.drawable.sym_def_app_icon);

            // 设置点赞按钮状态
            updateLikeButton(post.isLiked());

            // 点赞按钮点击事件
            likeButton.setOnClickListener(v -> {
                boolean newLikeState = !post.isLiked();
                post.setLiked(newLikeState);
                post.setLikeCount(post.getLikeCount() + (newLikeState ? 1 : -1));

                // 更新UI
                likeCount.setText(String.valueOf(post.getLikeCount()));
                updateLikeButton(newLikeState);
            });

            // 评论按钮点击事件
            commentButton.setOnClickListener(v -> {
                // TODO: 实现评论功能
                android.widget.Toast.makeText(context, "评论功能开发中...", Toast.LENGTH_SHORT).show();
            });
        }

        private void updateLikeButton(boolean isLiked) {
            if (isLiked) {
                likeButton.setImageResource(android.R.drawable.btn_star_big_on);
                likeButton.setColorFilter(ContextCompat.getColor(context, android.R.color.holo_red_dark));
            } else {
                likeButton.setImageResource(android.R.drawable.btn_star_big_off);
                likeButton.setColorFilter(ContextCompat.getColor(context, android.R.color.darker_gray));
            }
        }

        private String getTimeAgo(long timestamp) {
            long now = System.currentTimeMillis();
            long diff = now - timestamp;

            long seconds = diff / 1000;
            long minutes = seconds / 60;
            long hours = minutes / 60;
            long days = hours / 24;

            if (days > 0) {
                return days + "天前";
            } else if (hours > 0) {
                return hours + "小时前";
            } else if (minutes > 0) {
                return minutes + "分钟前";
            } else {
                return "刚刚";
            }
        }
    }
}