package com.example.icyclist;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import android.widget.Toast;
import java.util.List;

public class CommunityAdapter extends RecyclerView.Adapter<CommunityAdapter.CommunityViewHolder> {

    private Context context;
    private List<String> communityList;

    public CommunityAdapter(Context context, List<String> communityList) {
        this.context = context;
        this.communityList = communityList;
    }

    @NonNull
    @Override
    public CommunityViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_community, parent, false);
        return new CommunityViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull CommunityViewHolder holder, int position) {
        String community = communityList.get(position);
        holder.bind(community);
    }

    @Override
    public int getItemCount() {
        return communityList.size();
    }

    class CommunityViewHolder extends RecyclerView.ViewHolder {
        private TextView communityName, memberCount, postCount;

        public CommunityViewHolder(@NonNull View itemView) {
            super(itemView);

            communityName = itemView.findViewById(R.id.community_name);
            memberCount = itemView.findViewById(R.id.member_count);
            postCount = itemView.findViewById(R.id.post_count);
        }

        public void bind(String community) {
            communityName.setText(community);
            // 模拟成员数和帖子数
            memberCount.setText((int)(Math.random() * 1000 + 100) + " 成员");
            postCount.setText((int)(Math.random() * 500 + 50) + " 帖子");

            itemView.setOnClickListener(v -> {
                android.widget.Toast.makeText(context, "进入 " + community,Toast.LENGTH_SHORT).show();
                // TODO: 进入具体社区页面
            });
        }
    }
}