package com.example.icyclist;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.List;

public class LoginActivity extends AppCompatActivity {

    private EditText etUserId, etPassword;
    private Button btnLogin;
    private CheckBox cbAutoLogin;
    private List<User> userList;
    private SharedPreferences sharedPreferences;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        initViews();
        initUserData();
        setupListeners();

        // 检查是否已开启自动登录
        checkAutoLoginStatus();
    }

    private void initViews() {
        etUserId = findViewById(R.id.et_user_id);
        etPassword = findViewById(R.id.et_password);
        btnLogin = findViewById(R.id.btn_login);
        cbAutoLogin = findViewById(R.id.cb_auto_login);

        sharedPreferences = getSharedPreferences("user_prefs", MODE_PRIVATE);
    }

    private void initUserData() {
        userList = new ArrayList<>();
        // 添加模拟用户数据
        userList.add(new User("user001", "骑行爱好者", "123456"));
        userList.add(new User("user002", "山地车手", "123456"));
        userList.add(new User("user003", "公路车达人", "123456"));
        userList.add(new User("admin", "管理员", "admin123"));
    }

    private void setupListeners() {
        btnLogin.setOnClickListener(v -> {
            String userId = etUserId.getText().toString().trim();
            String password = etPassword.getText().toString().trim();

            if (userId.isEmpty() || password.isEmpty()) {
                Toast.makeText(LoginActivity.this, "请输入用户ID和密码", Toast.LENGTH_SHORT).show();
                return;
            }

            // 验证用户
            User user = validateUser(userId, password);
            if (user != null) {
                // 如果勾选了自动登录，则保存登录状态
                if (cbAutoLogin.isChecked()) {
                    saveLoginStatus(user);
                } else {
                    // 不自动登录时，清除之前的登录状态
                    clearLoginStatus();
                }

                // 跳转到主界面
                Intent intent = new Intent(LoginActivity.this, MainActivity.class);
                intent.putExtra("currentUser", user);
                startActivity(intent);
                finish();
            } else {
                Toast.makeText(LoginActivity.this, "用户ID或密码错误", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private User validateUser(String userId, String password) {
        for (User user : userList) {
            if (user.getUserId().equals(userId) && user.getPassword().equals(password)) {
                return user;
            }
        }
        return null;
    }

    private void saveLoginStatus(User user) {
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString("user_id", user.getUserId());
        editor.putString("username", user.getUsername());
        editor.putBoolean("auto_login", true); // 标记为自动登录
        editor.putBoolean("is_logged_in", true);
        editor.apply();
    }

    private void clearLoginStatus() {
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.remove("user_id");
        editor.remove("username");
        editor.remove("auto_login");
        editor.remove("is_logged_in");
        editor.apply();
    }

    private void checkAutoLoginStatus() {
        boolean autoLogin = sharedPreferences.getBoolean("auto_login", false);
        if (autoLogin) {
            boolean isLoggedIn = sharedPreferences.getBoolean("is_logged_in", false);
            if (isLoggedIn) {
                String userId = sharedPreferences.getString("user_id", "");
                String username = sharedPreferences.getString("username", "");
                User user = new User(userId, username, "");

                Intent intent = new Intent(LoginActivity.this, MainActivity.class);
                intent.putExtra("currentUser", user);
                startActivity(intent);
                finish();
            }
        }
        // 如果没有开启自动登录，就停留在登录界面
    }
}